package org.equi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Automation_Pract {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\admin\\workspace\\Equinity_Automation\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://automationpractice.com");
	
		WebElement signIn=driver.findElement(By.className("login"));
		signIn.click();
		
		WebElement emailCreate=driver.findElement(By.id("email_create"));
		emailCreate.sendKeys("nsmuralioct29@gmail.com");
		
		WebElement submitCreate=driver.findElement(By.id("SubmitCreate"));
		submitCreate.click();
		
		WebElement gender=driver.findElement(By.id("uniform-id_gender1"));
		gender.click();
		
		WebElement cfname=driver.findElement(By.id("customer_firstname"));
		cfname.sendKeys("Murali");
		
		WebElement clname=driver.findElement(By.id("customer_lasttname"));
		clname.sendKeys("Nandagopal");
		
		WebElement pwd=driver.findElement(By.id("passwd"));
		pwd.sendKeys("equinity");
		
		WebElement day=driver.findElement(By.id("days"));
		Select s=new Select(day);
		s.selectByValue("29");
		
		WebElement month=driver.findElement(By.id("months"));
		Select s1=new Select(month);
		s1.selectByVisibleText("October ");
		
		WebElement year=driver.findElement(By.id("years"));
		Select s2=new Select(year);
		s2.selectByVisibleText("1983");
		
		WebElement fname=driver.findElement(By.id("firstname"));
		fname.sendKeys("Murali");
		
		WebElement lname=driver.findElement(By.id("lastname"));
		lname.sendKeys("Nandagopal");
		
		WebElement comp=driver.findElement(By.id("company"));
		comp.sendKeys("Prismy Data SoftLabs");
		
		WebElement add1=driver.findElement(By.id("address1"));
		add1.sendKeys("Ayanavaram");
		
		WebElement cty=driver.findElement(By.id("city"));
		cty.sendKeys("Chennai");
		
		WebElement state=driver.findElement(By.id("id_state"));
		Select s3=new Select(state);
		s3.selectByVisibleText("Alabama");
		
		WebElement zip=driver.findElement(By.id("postcode"));
		zip.sendKeys("01234");
		
		WebElement country=driver.findElement(By.id("id_country"));
		Select s4=new Select(country);
		s4.selectByVisibleText("United States");
		
		WebElement phone=driver.findElement(By.id("phone_mobile"));
		phone.sendKeys("9940293215");
		
		WebElement addalias=driver.findElement(By.id("alias"));
		addalias.sendKeys("Chennai");
		
		WebElement register=driver.findElement(By.id("submitAccount"));
		register.click();
		
		
	}
	}
