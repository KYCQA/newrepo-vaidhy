package com.Signin;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Practise {

	public static void main(String[] args) {
		
		WebDriver driver= new InternetExplorerDriver();
		System.setProperty("webdriver.ie.driver","C:\\Users\\Admin\\Desktop\\New folder\\Selenium IE driver\\IEDriverServer_x64_3.13.0");
		driver.get("http://automationpractice.com");
		driver.findElement(By.xpath("a[text()='Sign in']")).click();
		driver.findElement(By.xpath("input[@id='email_create']")).sendKeys("lmdemo045@gmail.com");
		driver.findElement(By.xpath("button[@id='SubmitCreate']")).click();
		driver.findElement(By.xpath("input[@id='id_gender2']")).click();
		driver.findElement(By.xpath("input[@id='customer_firstname']")).sendKeys("abc");
		driver.findElement(By.xpath("input[@id='customer_lastname']")).sendKeys("xyz");
		driver.findElement(By.xpath("input[@id='address1']")).sendKeys("206 north spencer road");
		driver.findElement(By.xpath("input[@id='city']")).sendKeys("Spencer");
		WebElement dropdown1 = driver.findElement(By.xpath("id_state"));
		Select List = new Select(dropdown1);
		List.selectByVisibleText("Florida");
		driver.findElement(By.id("postcode"));
		driver.findElement(By.id("phone_mobile"));
		driver.findElement(By.id("alias"));
		driver.findElement(By.id("submitAccount"));
		driver.findElement(By.id("passwd"));
		driver.findElement(By.xpath("//*[contains(.,'My wishlists')]")).click();
		driver.findElement(By.id("//div[@class='product-content']")).click();
		driver.findElement(By.xpath("//div[@class='box-cart-bottom'//p[@id=wishlist_button"));
		Alert alert = null;
		alert.accept();
		driver.findElement(By.xpath("//div[@class='header_user_info']")).click();
		driver.findElement(By.xpath("//*[contains(.,'My wishlists')]")).click();
		driver.findElement(By.xpath("//div[@id='block-center']/tr[@id='wishlist_7610']")).isDisplayed();
		
		
		
		
		
		
		
				
		
		
		
		
		

	}

}
