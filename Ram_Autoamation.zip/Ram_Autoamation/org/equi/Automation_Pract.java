package org.equi;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Automation_Pract {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\admin\\workspace\\Equinity_Automation\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://automationpractice.com");
	
		WebElement signIn=driver.findElement(By.className("login"));
		signIn.click();
		
		WebElement emailCreate=driver.findElement(By.id("email_create"));
		emailCreate.sendKeys("ramgd123@gmail.com");
		
		WebElement submitCreate=driver.findElement(By.id("SubmitCreate"));
		submitCreate.click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@class='radio']")).click();
		//driver.findElement(By.id("customer_firstname")).sendKeys("Ram");
		//driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("Chandran");
		//driver.findElement(By.xpath("//input[@value='nsmuralioct29@gmail.com']")).click();
				
		WebElement cfname=driver.findElement(By.id("customer_firstname"));
		cfname.sendKeys("Murali");
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("Chandran");
		
		//WebElement clname=driver.findElement(By.id("customer_lasttname"));
		//clname.sendKeys("Chandra");
		
		WebElement pwd=driver.findElement(By.id("passwd"));
		pwd.sendKeys("equinity");
		
		WebElement day=driver.findElement(By.id("days"));
		Select s=new Select(day);
		s.selectByValue("29");
		
		WebElement month=driver.findElement(By.id("months"));
		Select s1=new Select(month);
		s1.selectByVisibleText("October ");
		
		Select year=new Select(driver.findElement(By.id("years")));
		year.selectByValue("1994");
		//WebElement year=driver.findElement(By.id("years"));
		//Select s2=new Select(year);
		//s2.selectByVisibleText("2000");
		
		driver.findElement(By.xpath("//input[@name='newsletter']")).click();
		
		WebElement fname=driver.findElement(By.id("firstname"));
		fname.sendKeys("Murali");
		
		WebElement lname=driver.findElement(By.id("lastname"));
		lname.sendKeys("Nandagopal");
		
		WebElement comp=driver.findElement(By.id("company"));
		comp.sendKeys("Prismy Data SoftLabs");
		
		WebElement add1=driver.findElement(By.id("address1"));
		add1.sendKeys("c22,TamilNadu housing board,velachery");
		
		WebElement cty=driver.findElement(By.id("city"));
		cty.sendKeys("Chennai");
		
		WebElement state=driver.findElement(By.id("id_state"));
		Select s3=new Select(state);
		s3.selectByVisibleText("Alabama");
		
		WebElement zip=driver.findElement(By.id("postcode"));
		zip.sendKeys("01234");
		
		WebElement country=driver.findElement(By.id("id_country"));
		Select s4=new Select(country);
		s4.selectByVisibleText("United States");
		
		WebElement phone=driver.findElement(By.id("phone_mobile"));
		phone.sendKeys("9940293215");
		
		WebElement addalias=driver.findElement(By.id("alias"));
		addalias.sendKeys("Chennai");
		
		WebElement register=driver.findElement(By.id("submitAccount"));
		register.click();
		
		driver.findElement(By.xpath("//span[contains(text(),'My wishlists')]")).click();
		
		driver.findElement(By.xpath("//a[contains(text(),'Faded Short Sleeve T-shirts')]")).click();
		
		driver.findElement(By.xpath("//span[contains(text(),'Add to cart')]")).click();
		
		driver.findElement(By.xpath("//span[@title='Close window']")).click();
		
		driver.findElement(By.xpath("//span[contains(text(),'Proceed to checkout')]")).click();
		
		//driver.findElement(By.xpath("//b[contains(text(),'Cart')]")).click();
		
		
		
	}
	}
