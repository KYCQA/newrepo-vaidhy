package userRegistration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class User {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C://ChromeDriver//chromedriver.exe");
		RemoteWebDriver driver=new ChromeDriver();
driver.get("http://automationpractice.com/index.php");
driver.findElementByClassName("login").click();
System.out.println("Button clicked");

driver.findElementById("email").sendKeys("sharu.7589@gmail.com");
driver.findElementById("passwd").sendKeys("Vibhu");
driver.findElementByXPath("//button[@class='button btn btn-default button-medium']").click();

driver.findElementByXPath("//span[text()='My wishlists']").click();
driver.findElementByXPath("//a[text()='Top sellers']").click();
driver.findElementByXPath("//*[@id='best-sellers_block_right']/div/ul/li[1]/a/img").click();

if (driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).isDisplayed()){
	System.out.println("Wish List is Displayed");
}
driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).click();
Thread.sleep(3000);
if (driver.findElement(By.xpath("//p[@class='fancybox-error']")).isDisplayed()){
	System.out.println("Item added pop up appears");
}

driver.findElementByXPath("//a[@class='fancybox-item fancybox-close']").click();

System.out.println("popup closed");
driver.navigate().refresh();
driver.findElement(By.xpath("//a[@title='View my customer account']/span")).click();
driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
if (driver.findElement(By.xpath("//tr/td[1]")).isDisplayed()){
	System.out.println("Item is added in my wish list");

}
driver.quit();

	}

}
