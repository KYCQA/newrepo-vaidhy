package userRegistration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class UserReg {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver","C://ChromeDriver//chromedriver.exe");
		RemoteWebDriver driver=new ChromeDriver();
driver.get("http://automationpractice.com/index.php");
driver.findElementByClassName("login").click();
System.out.println("Button clicked");
driver.findElementById("email_create").sendKeys("sharu.7589@gmail.com");


driver.findElementById("authentication").click();

driver.findElementByXPath("//button[@name='SubmitCreate']").click();
Thread.sleep(3000);
System.out.println("Button clicked");
driver.findElementById("id_gender2").click();
driver.findElementByXPath("//input[@id='customer_firstname']").sendKeys("Sharanya");
driver.findElementByXPath("//input[@id='customer_lastname']").sendKeys("R");

driver.findElementById("passwd").sendKeys("Vibhu");
/*driver.findElementByXPath("//input[@name='firstname']").sendKeys("Sharanya");
driver.findElementByXPath("//input[@name='lastname']").sendKeys("R");
*/
driver.findElementById("address1").sendKeys("Ganesh Nagar Madipakkam");
driver.findElementById("city").sendKeys("Chennai");


WebElement state= driver.findElementById("id_state");
Select drpdown= new Select(state);
List<WebElement> options = drpdown.getOptions();
int size = options.size();
System.out.println(size);
drpdown.selectByIndex(15);
driver.findElementById("other").sendKeys("Test");
driver.findElementByXPath("//input[@id='phone_mobile']").sendKeys("9884049547");
driver.findElementById("postcode").sendKeys("60091");

driver.findElementByXPath("//input[@id='alias']").sendKeys("Ganesh Nagar ");
driver.findElementByXPath("//button[@id='submitAccount']").click();
System.out.println("User Reg Successful");

driver.findElementByXPath("//span[text()='My wishlists']").click();
driver.findElementByXPath("//a[text()='Top sellers']").click();
driver.findElementByXPath("//*[@id='best-sellers_block_right']/div/ul/li[1]/a/img").click();

if (driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).isDisplayed()){
	System.out.println("Wish List is Displayed");
}
driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).click();
Thread.sleep(3000);
if (driver.findElement(By.xpath("//p[@class='fancybox-error']")).isDisplayed()){
	System.out.println("Item added pop up appears");
}

driver.findElementByXPath("//a[@class='fancybox-item fancybox-close']").click();

System.out.println("popup closed");
driver.navigate().refresh();
driver.findElement(By.xpath("//a[@title='View my customer account']/span")).click();
driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
if (driver.findElement(By.xpath("//tr/td[1]")).isDisplayed()){
	System.out.println("Item is added in my wish list");

}
driver.quit();











//driver.close();
	}

}
