package Pck1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RegnewCustomer {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com");
		driver.findElement(By.xpath("//a[@title='Log in to your customer account' and contains(text(),'Sign in')]")).click();
	   
		String mail="mounica30@gmail.com";
		driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys(mail);
		
		driver.findElement(By.xpath("//*[@id='SubmitCreate']")).click();
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='id_gender2' and @name='id_gender']")).click();
			
		    String FirstN="Mounica";
		driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys(FirstN);
		String LastN="Madhu";
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys(LastN);
		String PassWord="Harshat";
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys(PassWord);
		
		Select date=new Select(driver.findElement(By.xpath("//select[@id='days']")));
		Select month=new Select(driver.findElement(By.xpath("//select[@id='months']")));
		Select year=new Select(driver.findElement(By.xpath("//select[@id='years']")));

		date.selectByValue("18");
		month.selectByIndex(1);                
		year.selectByValue("1984");
		     
		String Add="No.11,sivaIllam,BharathiNagar  ,Tambaram";
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys(Add);
		
		String  City="Chennai";
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys(City);
		  
		 
		String state="Alabama";
		 Select  statevalue =  new Select(driver.findElement(By.xpath("//select[@id='id_state']")));
		statevalue.selectByIndex(2);
		  
		
		String zipcode="60086";
		driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys(zipcode);
		
		 
		String country="United States";       
		Select countryvalue = new Select(driver.findElement(By.xpath("//select[@id='id_country']"))) ; 
		 countryvalue.selectByIndex(1);
		                                                
		String mob="9898988888";
		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys(mob);
		
		driver.findElement(By.xpath("//input[@id='alias']")).clear();
		String aliass="Elam";
		driver.findElement(By.xpath("//input[@id='alias']")) .sendKeys(aliass);
		 
		
		
		driver.findElement(By.xpath("//*[@id='submitAccount']")).click();		
		
		
		
		String Myname=FirstN+ " "+LastN;
	    WebElement nam=driver.findElement(By.xpath("//a[@title='View my customer account']"));
				
		if(nam.getText().equals(Myname))
		{
			System.out.println("My Account Name displayed correctly");
		}
		else
			System.out.println("My Account Name is displayed wrongly");
		
		
		if(driver.findElement(By.xpath("//a[@title='My wishlists']")).isDisplayed())
		{
			System.out.println("Wish List is displayed");
		}   
		else
			System.out.println("Wish List is not displayed");
		 
		           
		
		driver.findElement(By.xpath("//a[contains(@title,'My wishlists')]")).click();
		Thread.sleep(2000);
		
		 
		if(driver.findElement(By.xpath("//a[@title='View a top sellers products']")).isDisplayed())
		{                                                                              
			System.out.println("Top Sellers List is displayed");
		}
		else
			System.out.println("Top Sellers List is not displayed"); 
		
		
		
		driver.findElement(By.xpath("//a[@title='View a top sellers products']")).click();
		
		
		
		
		if(driver.findElements(By.xpath("//a[@id='wishlist_button']")).isEmpty())
				{
			      System.out.println("WishList button is displayed");
				}
				else
					System.out.println("Wishlist button is not displayed");
		
		
		if(driver.findElements(By.xpath("//p[@id='add_to_cart']/child::button/child::span")).isEmpty())

		{
			System.out.println("Add to wishlist button is displayed");                      
		}
		else
			System.out.println(" Add to Wishlist button is not displayed");

		driver.findElement(By.xpath("//p[@id='add_to_cart']/child::button/child::span")).click();
		driver.findElement(By.xpath("//a[@title='Close']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@class='account']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[contains(@title,'My wishlists')]")).click();
		
		
		
		driver.close();       
	}                          
}                                                                                                                                                                                                     
            
                                          