package dinesh;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.gargoylesoftware.htmlunit.javascript.host.dom.Document;

public class Test {

	public static void main(String[] args) {	

		final char c = ' ';	
		final String fname = "DINESH";
		final String lname = "KANNAN";
		final String name = fname+c+lname;	
		System.out.println("Full name is "+name);
		//invoking browser
		System.setProperty("webdriver.chrome.driver","C:/Users/admin/workspace/Equinity_Automation/Driver/chromedriver.exe");
		RemoteWebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		//step1
		driver.get("http://automationpractice.com");
		driver.findElementByLinkText("Sign in").click();

		//step2
		driver.findElementByXPath("//input[@id='email_create']").sendKeys("testdinesh10@test.com");
		driver.findElementById("SubmitCreate").click();

		//Step3
		driver.findElementById("uniform-id_gender1").click();
		driver.findElementById("customer_firstname").sendKeys(fname);
		driver.findElementById("customer_lastname").sendKeys(lname);
		driver.findElementById("address1").sendKeys("No.4 Street Name");
		driver.findElementByXPath("//input[@id='city']").sendKeys("XYZ");
		WebElement src = driver.findElementByXPath("//select[@id='id_state']");
		Select drop = new Select(src);
		drop.selectByIndex(10);
		driver.findElementById("postcode").sendKeys("10012");
		WebElement src1 = driver.findElementByXPath("//select[@id='id_country']");
		Select drop1 = new Select(src1);
		drop1.selectByVisibleText("United States");
		driver.findElementById("phone_mobile").sendKeys("9190001111");
		driver.findElementById("phone_mobile").sendKeys(Keys.TAB);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("document.getElementById('alias').value='Tet Address123';");

		//Selenium .click NOT working hence used JavaScript executor
		/*driver.findElementById("//input[@id='alias']").clear();
		driver.findElementById("//input[@id='alias']").sendKeys("Test Address");*/

		driver.findElementById("submitAccount").click();
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElementByXPath("//*[text()[contains(.,'is required')]]")));
		System.out.println("Password is a requilred filed. Please enter password");
		driver.findElementByXPath("//input[@id='passwd']").sendKeys("test123");

		//Step4
		driver.findElementById("submitAccount").click();

		String text1 = driver.findElementByXPath("//span[@class='navigation_page']").getText();

		if (text1.equals("My account")){
			System.out.println("User Logged in Successully and taken to My Account Page");	
		}

		//Step5
		String text2 = driver.findElementByXPath("//a[@class='account']/span").getText();
		if (text2.equals(name)){
			System.out.println("Name Displayed successfuly");	
		}

		//Step6 & 7
		boolean wish = driver. findElementByXPath("//a[@title='My wishlists']//span").isDisplayed();
		if (wish==true){
			System.out.println("My WISHLISTS is dispalyed");
			driver.findElementByXPath("//a[@title='My wishlists']//span").click();
			
		}

		//Step8 & 9
		String ans1 = driver.findElementByXPath("//div[@class='product-content']//a").getText();
		boolean top = driver.findElementByXPath("//div[@class='block products_block']").isDisplayed();
		if(top==true){
			System.out.println("Top Sellers list is displayed");
			driver.findElementByXPath("//div[@class='product-content']//a").click();	
		}

		//Step10
		int y1 = driver.findElementByXPath("//span[text()='Add to cart']").getLocation().getY();
		int y2 = driver.findElementByXPath("//a[@id='wishlist_button']").getLocation().getY();
		if (y2>y1){
			System.out.println("Add to Wish List button is dispalyed under Add to Cart");
		}

		//step11
		driver.findElementById("wishlist_button").click();

		//Step12
		boolean list = driver.findElementByXPath("//p[text()='Added to your wishlist.']").isDisplayed();
		if(list==true){
			System.out.println("item added to wish list");	
			driver.findElementByXPath("//a[@class='fancybox-item fancybox-close']").click();
		}

		//Step13
		driver.findElementByXPath("//a[@class='account']/span").click();
		driver.findElementByXPath("//a[@title='My wishlists']//span").click();
		driver.findElementByXPath("//a[text()[contains(.,'My wishlist')]]").click();
		String ans2 = driver.findElementByXPath("//p[@class='product-name']").getText();

		if(ans1.equals(ans2)){
			System.out.println("Item Added Successfully into Wish List");	
		}
	}	
}
