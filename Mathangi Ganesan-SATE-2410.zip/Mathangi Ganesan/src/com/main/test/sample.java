package com.main.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class sample {
	public static void main(String args[]) throws InterruptedException
	{
		
System.setProperty("webdriver.chrome.driver","C://ChromeDriver//chromedriver.exe");
WebDriver driver=new ChromeDriver();

driver.get("http://www.automationpractice.com");
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
driver.findElement(By.xpath("//a[@class='login']")).click();
driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys("jothisathya88@gmail.com");
driver.findElement(By.xpath("//span/i[@class='icon-user left']")).click();
driver.findElement(By.xpath("//input[@id='id_gender2']")).click();
driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("Sathyajothi");
driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("S");
driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("sathya123");
driver.findElement(By.xpath("//input[@id='address1']")).sendKeys("chetpet");
driver.findElement(By.xpath("//input[@id='city']")).sendKeys("chennai");
WebElement state=driver.findElement(By.xpath("//select[@id='id_state']"));
Select selectstate=new Select(state);
selectstate.selectByIndex(1);
driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys("12345");
driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys("9840872021");
driver.findElement(By.xpath("//input[@id='alias']")).sendKeys("My address");
driver.findElement(By.xpath("//span[text()='Register']")).click();
driver.findElement(By.xpath("//span[text()='My wishlists']")).click();
if (driver.findElement(By.xpath("//a[text()='Top sellers']")).isDisplayed()){
	System.out.println("I can see Top Sellers.");
}
driver.findElement(By.xpath("//*[@id='best-sellers_block_right']/div/ul/li[1]/a/img")).click();
if (driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).isDisplayed()){
	System.out.println("I can see Add to wishlist");
}
driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).click();
if (driver.findElement(By.xpath("//p[text()='Added to your wishlist.']")).isDisplayed()){
	System.out.println("Item Added to Wish LIST Popup appears");
}
driver.findElement(By.xpath("//div[@class='fancybox-skin']/a[@title='Close']")).click();
System.out.println("Closed the popup");
driver.navigate().refresh();
driver.findElement(By.xpath("//a[@title='View my customer account']/span")).click();
driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
if (driver.findElement(By.xpath("//tr/td[1]")).isDisplayed()){
	System.out.println("Verified");

}
driver.quit();
}
}

