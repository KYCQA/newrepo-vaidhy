package createUser;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CreateUserLogin {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		driver.findElement(By.partialLinkText("Sign in")).click();
		driver.findElement(By.id("email_create")).sendKeys("testAuto14334@gmail.com");
		driver.findElement(By.xpath("//span[text()[contains(.,'Create an account')]]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("id_gender1")).click();
		driver.findElement(By.id("customer_firstname")).sendKeys("TestUser");
		driver.findElement(By.id("customer_lastname")).sendKeys("TestLastName");
		driver.findElement(By.id("passwd")).sendKeys("testPasswrd");
		driver.findElement(By.id("passwd")).sendKeys("testPasswrd");
		driver.findElement(By.id("days")).sendKeys("6");
		Select mon = new Select(driver.findElement(By.id("months")));
		mon.selectByValue("11");
		Select year = new Select(driver.findElement(By.id("years")));
		year.selectByValue("1991");
		driver.findElement(By.id("firstname")).sendKeys("TestUser");
		driver.findElement(By.id("lastname")).sendKeys("TestLastName");
		driver.findElement(By.id("address1")).sendKeys("NorthTown");
		driver.findElement(By.id("city")).sendKeys("NewCity");
		Select state = new Select(driver.findElement(By.id("id_state")));
		state.selectByValue("1");
		driver.findElement(By.id("postcode")).sendKeys("12345");
		Select country = new Select(driver.findElement(By.id("id_country")));
		country.selectByValue("21");
		driver.findElement(By.id("phone_mobile")).sendKeys("9790789544");
		driver.findElement(By.xpath("//span[text()='Register']")).click();
		WebElement name = driver.findElement(By.xpath("//a[@class='account']/span"));
		if(name.getText().contains("TestUser")){
			System.out.println("UserLoginVerified");
		}
		else{
			System.out.println("Error in Name");
		}
		WebElement wishList = driver.findElement(By.xpath("//span[text()[contains(.,'My wishlists')]]"));
		if(wishList.getText().contains("LIST")){
			System.out.println("My Wishlists present");
		}
		else{
			System.out.println("Error in WishList :"+wishList.getText());
		}
		wishList.click();
		WebElement topSeller = driver.findElement(By.xpath("//a[text()[contains(.,'Top sellers')]]"));
		if(topSeller.getText().contains("TOP")){
			System.out.println("Top Sellers is present");
		}
		else{
			System.out.println("Error in Top Seller");
		}
		WebElement wishItem = driver.findElement(By.xpath("(//img[@class='replace-2x img-responsive'])[1]"));
		String wish = wishItem.getText();
		System.out.println(wish);
		wishItem.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).click();
		Set<String> windows = driver.getWindowHandles();
		System.out.println("Open windows:"+windows.size());
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@title='Close']")).click();
		Thread.sleep(2000);
		WebElement name1 = driver.findElement(By.xpath("//a[@class='account']/span"));
		name1.click();
		WebElement wishList1 = driver.findElement(By.xpath("//span[text()[contains(.,'My wishlists')]]"));
		wishList1.click();
		WebElement added = driver.findElement(By.xpath("(//a[text()[contains(.,'My wishlist')]]/following::td)[1]"));
		if(added.getText().contains("1")){
			System.out.println("WishlistAdded");
		}
		
	}

}
