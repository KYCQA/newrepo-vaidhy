import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class create {
	
		
		
		
		public static void main(String[] args) throws InterruptedException {
			System.setProperty("webdriver.chrome.driver","C:/ChromeDriver/chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			
			String baseUrl = "http://automationpractice.com/index.php";
	        driver.get(baseUrl);
	        
	        //Click on Signin
	        WebElement ClickSignin=driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a"));
	        ClickSignin.click();
	        
	        //CreateNewAccount
	        WebElement CreateEmail = driver.findElement(By.id("email_create"));
	        CreateEmail.sendKeys("TestTest12345@gmail.com");
	        driver.findElement(By.xpath("//*[@id='SubmitCreate']/span/i")).click();
	        
	        
	        Thread.sleep(1000);
	        WebElement Form=driver.findElement(By.xpath("//*[@id='account-creation_form']"));
	        Form.click();
	        System.out.println("waitover");
	        Select Mr = new Select(driver.findElement(By.xpath("//*[@id='uniform-id_gender1']")));
	        System.out.println("Passed");
	       
	        driver.findElement(By.xpath("//*[@id='customer_firstname']")).sendKeys("Testing");
	        driver.findElement(By.xpath("//*[@id='customer_lastname']")).sendKeys("Test");
	        driver.findElement(By.id("passwd")).sendKeys("");
	        
	        Select Date = new Select(driver.findElement(By.xpath("//*[@id='days']")));
	        Date.selectByVisibleText("1");
	        Select Month =new Select(driver.findElement(By.xpath("//*[@id='months']")));
	        Month.selectByVisibleText("January");
	        Select Year =new Select(driver.findElement(By.xpath("//*[@id='years']")));
	        Year.selectByVisibleText("1996");
	        
	        driver.findElement(By.xpath("//*[@id='firstname']")).sendKeys("Testing");
	        driver.findElement(By.xpath("//*[@id='lastname']")).sendKeys("Test");
	        driver.findElement(By.xpath("//*[@id='address1']")).sendKeys("N.o 50, Annngar"); 
	        driver.findElement(By.xpath("//*[@id='city']")).sendKeys("Florida");
	        driver.close();
	        
	        Select State = new Select(driver.findElement(By.xpath("//*[@id='id_state']")));
	        State.selectByVisibleText("Alabama");
	        driver.findElement(By.xpath("//*[@id='postcode']")).sendKeys("987654");
	        driver.findElement(By.xpath("//*[@id='phone_mobile']")).sendKeys("9876543234");
	        driver.findElement(By.xpath("//*[@id='alias']")).sendKeys("albert");
	        driver.findElement(By.xpath("//*[@id='submitAccount']")).click();
	      

}
}
