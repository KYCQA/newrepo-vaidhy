package com.main.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pageObj.test.HomePage;

public class TestMain {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.automationpractice.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		//Sign in Application
		driver.findElement(By.xpath("//a[@class='login']")).click();
	//	WebDriverWait wait = new WebDriverWait(driver, 5);
		driver.findElement(By.xpath("//input[@id='email_create']")).click();
		driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys("alexautomation123@gmail.com");
		driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();
		
		driver.findElement(By.xpath("//input[@id='id_gender1']")).click();
		driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("Alex");
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("Rosario");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("1qaz2wsx");
		
		WebElement day = driver.findElement(By.id("days"));
		Select days = new Select(day);
		days.selectByValue("7");
		
		WebElement months = driver.findElement(By.id("months"));
		Select month = new Select(months);
		month.selectByValue("7");
		
		WebElement years = driver.findElement(By.id("years"));
		Select Year = new Select (years);
		Year.selectByValue("1988");
		
		driver.findElement(By.xpath("//input[@id='firstname']")).sendKeys("Mathew");
		driver.findElement(By.xpath("//input[@id='lastname']")).sendKeys("Garments");
		driver.findElement(By.xpath("//input[@id='company']")).sendKeys("Texido");
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys("No.6 Gandhi nagar");
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys("chennai");
		
		WebElement States = driver.findElement(By.id("id_state"));
		Select state = new Select (States);
		state.selectByValue("10");
		
		driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys("411057");
		
		/*WebElement Countries = driver.findElement(By.id("id_country"));
		Select country = new Select (Countries);
		country.selectByValue("United States");*/
		
		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys("9790369969");
		driver.findElement(By.xpath("//input[@id='alias']")).sendKeys("Same My address");
		
		driver.findElement(By.xpath("//button[@id='submitAccount']")).click();
		
		if (driver.getPageSource().contains("Welcome to your account.")){
			System.out.println("Successfully Logged In and launched into My Account Page");
		} else{
			System.out.println("Login is failure, Please fill the data");
		}
		if (driver.findElement(By.xpath("//a[@title='View my customer account']/span")).getText().equals("Alex Rosario")){
			System.out.println("I can see my name on top of the corner for static data");
		}
		
		if (driver.findElement(By.xpath("//a[@title='My wishlists']/span")).isDisplayed()){
			System.out.println("I can see My Wish LIST");
		}
		
		if (driver.findElement(By.xpath("//form[@id='form_wishlist']/fieldset/h3")).getText().equals("New wishlist")){
			System.out.println("I have selected My Wish List");
		}
		
		if (driver.findElement(By.xpath("//div[@id='best-sellers_block_right']/h4/a")).getText().equals("Top sellers")){
			System.out.println("Top Sellers are displayed at left side panel");
		}
		
		driver.close();
	}
}
