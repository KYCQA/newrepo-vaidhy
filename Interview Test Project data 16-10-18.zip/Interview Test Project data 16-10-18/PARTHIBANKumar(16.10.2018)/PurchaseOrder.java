package registration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

//Script done by PARTHIBAN KUMAR on 16.10.2018

public class PurchaseOrder {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("WebDriver.Chrome.driver", "./driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();

		driver.findElement(By.xpath("//a[@title='Log in to your customer account']")).click();
		driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys("parthiban.ku@gmail.com");
		driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();

		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='id_gender1']")).click();
		driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("Parthiban");
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("Kumar");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("parthi@3009");
		driver.findElement(By.xpath("//input[@id='company']")).sendKeys("Volante");
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys("No.02 Car Street, Kandachipuram");
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys("Villupuram");			
		Select state=new Select(driver.findElement(By.xpath("//select[@id='id_state']")));
		state.selectByVisibleText("New Jersey");
		driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys("07099");
		Select country=new Select(driver.findElement(By.xpath("//select[@id='id_country']")));
		country.selectByVisibleText("United States");					
		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys("9941142250");
		driver.findElement(By.xpath("//input[@id='alias']")).clear();
		driver.findElement(By.xpath("//input[@id='alias']")).sendKeys("Home Address");
		driver.findElement(By.xpath("//button[@id='submitAccount']")).click();



		if (driver.findElement(By.linkText("Parthiban Kumar")) != null)
		{
			System.out.print("User Name is Correct" + "\n" );
		}
		else{
			System.out.print("User Name is InCorrect" + "\n");

		}


		if (driver.findElement(By.linkText("MY WISHLISTS")) != null)
		{
			System.out.print("MY WISHLISTS is Present " + "\n");
		}
		else{
			System.out.print("MY WISHLISTS is Not Present");

		}

		driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
		driver.findElement(By.xpath("//img[@src='http://automationpractice.com/img/p/2/0/20-small_default.jpg']")).click();
		driver.findElement(By.xpath("//a[@id='wishlist_button']")).click();

		//Check the item is added to the wishlist		
		Alert alert=driver.switchTo().alert();
		if(alert.getText().equalsIgnoreCase("Item added to the wishlist")){
			System.out.println("Great!!! Item added to the wishlist");
		}
		alert.dismiss();

	}

}

//THANK YOU!

