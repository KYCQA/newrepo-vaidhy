package Newcustomer;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Customer {

d//public class Customer {

	private static final String By = null;

	public Customer() {
				
		
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub		

			//WebDriver driver = new chromedriver();				
			WebDriver driver = new FirefoxDriver(); 
			

			String url ="http://www.automationpractice.com";
			driver.get(url);		
				
			//
			
				String title = driver.getTitle();
				driver.findElement(By.xpath("input[@class='login']")).click();					
				driver.findelement(By.xpath("//input[@id='email_create']']")).sendkeys("srinivasank@gmail.com");
				driver.findElement(By.xpath("input[@text='createaccount']")).click();								
				driver.findelement(By.xpath("//input[@id='customer_firstname']']")).sendkeys("sathish");
				driver.findelement(By.xpath("//input[@id='customer_lastname']")).sendkeys("kumar");
				driver.findelement(By.xpath("//input[@id='email']")).sendkeys("srinivasank@gmail.com");
				driver.findelement(By.xpath("//input[@id='//input[@value='1']']")).click();
				driver.findelement(By.xpath("//input[@id='email']")).sendkeys("Usermail");		
				driver.findelement(By.xpath("//input[@id='customer_firstname']']")).sendkeys("sathish");
				driver.findelement(By.xpath("//input[@id='customer_lastname']")).sendkeys("kumar");
				driver.findelement(By.xpath("//input[@id='company']")).sendkeys("eqniti");
				driver.findelement(By.xpath("//input[@id='adress']")).sendkeys("dlfchennai");
				driver.findelement(By.xpath("//input[@id='phone_mobile']")).sendkeys("23323444");
				driver.findelement(By.xpath("//input[@id='register']")).click();			
				findElement(By.xpath("//label[text()='User Name:']/following::div/input")).sendKeys(Keys.TAB);

				
				

						
				System.out.println("Title of the page is : " + title);
				System.out.println("Length of the title is : "+ titleLength);				
				String actualUrl = driver.getCurrentUrl();
				if (actualUrl.equals(url)){
					System.out.println("Verification Successful - The correct Url is opened.");
				}else{
					System.out.println("Verification Failed - An incorrect Url is opened.");
					//In case of Fail, you like to print the actual and expected URL for the record purpose
					System.out.println("Actual URL is : " + actualUrl);
					System.out.println("Expected URL is : " + url);
				}

			driver.close();
			}
		}
		
	}

}
