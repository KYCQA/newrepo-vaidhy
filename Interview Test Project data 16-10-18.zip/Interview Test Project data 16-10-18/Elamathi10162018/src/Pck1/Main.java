package Pck1;

import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Main {
	
	//public static void main(String[] args) throws InterruptedException{
	
	@Test
	public static void main() throws InterruptedException{
		
		
		
		
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("http://automationpractice.com");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@title='Log in to your customer account' and contains(text(),'Sign in')]")).click();
		
		String mail="mathivijayasarathy@mail.com";
		driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys(mail);
		
		driver.findElement(By.xpath("//*[@id='SubmitCreate']")).click();
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='id_gender2' and @name='id_gender']")).click();
			
		String FirstN="Ela";
		driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys(FirstN);
		String LastN="mathi";
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys(LastN);
		String PW="kavinkapil";
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys(PW);
		
		Select d=new Select(driver.findElement(By.xpath("//select[@id='days']")));
		Select m=new Select(driver.findElement(By.xpath("//select[@id='months']")));
		Select y=new Select(driver.findElement(By.xpath("//select[@id='years']")));

		d.selectByValue("18");
		m.selectByIndex(1);
		//m.selectByValue("January ");	
		y.selectByValue("1984");
		
		String Add="No20,second floorShesathri Building,Valasaravakkam";
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys(Add);
		
		String City="Chennai";
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys(City);
		
		
		String stat="Alabama";
		Select statevalue = new Select(driver.findElement(By.xpath("//select[@id='id_state']")));
		statevalue.selectByIndex(2);
		
		
		String zipcode="60086";
		driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys(zipcode);
		
		
		String count="United States";
		
		Select countryvalue = new Select(driver.findElement(By.xpath("//select[@id='id_country']")));
		countryvalue.selectByIndex(1);
		//countryvalue.selectByValue(count);
		
		
		String mob="916641020";
		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys(mob);
		
		driver.findElement(By.xpath("//input[@id='alias']")).clear();
		String aliass="Elam";
		driver.findElement(By.xpath("//input[@id='alias']")).sendKeys(aliass);
		
		
		
		driver.findElement(By.xpath("//*[@id='submitAccount']")).click();		
		
		
		
		String Myname=FirstN+ " "+LastN;
	    WebElement nam=driver.findElement(By.xpath("//a[@title='View my customer account']"));
				
		if(nam.getText().equals(Myname))
		{
			System.out.println("My Account Name displayed correctly");
		}
		else
			System.out.println("My Account Name is displayed wrongly");
		
		
		if(driver.findElement(By.xpath("//a[@title='My wishlists']")).isDisplayed())
		{
			System.out.println("Wish List is displayed");
		}
		else
			System.out.println("Wish List is not displayed");
		
		
		
		driver.findElement(By.xpath("//a[contains(@title,'My wishlists')]")).click();
		Thread.sleep(2000);
		
		
		if(driver.findElement(By.xpath("//a[@title='View a top sellers products']")).isDisplayed())
		{
			System.out.println("Top Sellers List is displayed");
		}
		else
			System.out.println("Top Sellers List is not displayed");
		
		
		
		driver.findElement(By.xpath("//a[@title='View a top sellers products']")).click();
		
		
		
		
		if(!driver.findElements(By.xpath("//a[@id='wishlist_button']")).isEmpty())
				{
			      System.out.println("WishList button is displayed");
				}
				else
					System.out.println("Wishlist button is not displayed");
		
		
		if(!driver.findElements(By.xpath("//p[@id='add_to_cart']/child::button/child::span")).isEmpty())

		{
			System.out.println("Add to wishlist button is displayed");
		}
		else
			System.out.println(" Add to Wishlist button is not displayed");

		driver.findElement(By.xpath("//p[@id='add_to_cart']/child::button/child::span")).click();
		
		
		
		
		driver.findElement(By.xpath("//a[@title='Close']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@class='account']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[contains(@title,'My wishlists')]")).click();
		
		
		
		driver.close();
	}
	
	 }
