package registration;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CustomerRegistration {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.get("https://automationpractice.com");
		driver.findElement(By.xpath("//a[@title='Log in to your customer account']")).click();
		driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys("j.lavanyaeee@gmail.com");
		driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();
		//Enter the customer details
		driver.findElement(By.xpath("//input[@id='id_gender2']")).click();
		driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("lavanya");
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("jayachandran");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("indium@123");
		driver.findElement(By.xpath("//input[@id='company']")).sendKeys("indium");
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys("teachers colony");
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys("tadepalligudem");
		driver.findElement(By.xpath("//input[@id='id_state']")).sendKeys("andhrapradesh");
		Select state=new Select(driver.findElement(By.name("id_country")));
		state.selectByVisibleText("Minnesota");
		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys("9959657256");
		driver.findElement(By.xpath("//input[@id='alias']")).clear();
		driver.findElement(By.xpath("//input[@id='alias']")).sendKeys("Home");
		driver.findElement(By.xpath("//button[@id='submitAccount']")).submit();
		//Click on My Wishlist
		driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
		driver.findElement(By.xpath("//img[@src='http://automationpractice.com/img/p/2/0/20-small_default.jpg']")).click();
		driver.findElement(By.xpath("//a[@id='wishlist_button']")).click();
		//Verify the item is added to the wishlist		
		Alert alert=driver.switchTo().alert();
		if(alert.getText().equalsIgnoreCase("Item added to the wishlist")){
			System.out.println("Item added to the wishlist");
		}
		alert.dismiss();
	}

}
