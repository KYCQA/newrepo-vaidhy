package com.main.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class CreateAccount {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.automationpractice.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[contains(text(), 'Sign in')]")).click();
		driver.findElement(By.xpath("//input[@id='email_create']")).click();
		driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys("selvi.candra.bose@gmail.com");
		driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();
		
		driver.findElement(By.xpath("//input[@id='id_gender1']")).click();
		driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("Kalaivani");
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("chandrabose");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("kalaivan");
		
		WebElement dayToSelect = driver.findElement(By.id("days"));
		WebElement monthToSelect = driver.findElement(By.id("months"));
		WebElement yearToSelect = driver.findElement(By.id("years"));
		Select Day = new Select(dayToSelect);
		Select Month = new Select(monthToSelect);
		Select Year = new Select (yearToSelect);
		Day.selectByValue("2");
		Month.selectByValue("5");
		Year.selectByValue("1990");
		
		driver.findElement(By.xpath("//input[@id='firstname']")).sendKeys("kalaivani");
		driver.findElement(By.xpath("//input[@id='lastname']")).sendKeys("Chandrabose");
		driver.findElement(By.xpath("//input[@id='company']")).sendKeys("Capgemini");
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys("No.11 GST Road");
        driver.findElement(By.xpath("//input[@id='address2']")).sendKeys("Singaperumal Kovil");
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys("chennai");
		
		
		WebElement StateToSelect = driver.findElement(By.id("id_state"));
		WebElement CountryToSelect = driver.findElement(By.id("id_country"));
		Select state = new Select (StateToSelect);
		Select country = new Select (CountryToSelect);
		state.selectByIndex(2);
		country.selectByIndex(1);
		
		driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys("41105");		
		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys("9566828338");
		driver.findElement(By.xpath("//input[@id='alias']")).sendKeys("Same My address");	
		driver.findElement(By.xpath("//button[@id='submitAccount']")).click();
		
		if (driver.getPageSource().contains("Welcome to your account.")){
			System.out.println("Successfully created account and navigated to My Account Page");
		} else{
			System.out.println("failure for account creation, as field values are missing");
		}
		if (driver.findElement(By.xpath("//a[@title='View my customer account']/span")).getText().equals("Kalaivani chandrabose")){
			System.out.println("I can see my name on top of the corner for static data");
		}
		
		if (driver.findElement(By.xpath("//a[@title='My wishlists']/span")).isDisplayed()){
			System.out.println("I can see My Wish LIST");
		}
		
		driver.quit();
	}
}
