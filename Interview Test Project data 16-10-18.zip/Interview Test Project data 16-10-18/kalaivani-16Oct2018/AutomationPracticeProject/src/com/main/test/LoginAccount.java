package com.main.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class LoginAccount {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:/ChromeDriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.automationpractice.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[contains(text(), 'Sign in')]")).click();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("selvi.candra.bose@gmail.com");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("kalaivan");
		driver.findElement(By.xpath("//button[@id='SubmitLogin']")).click();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
		
		if (driver.findElement(By.xpath("//a[text()='Top sellers']")).isDisplayed()){
			System.out.println("I can see Top Sellers and can able to click on First one");
		}
		
		driver.findElement(By.xpath("//*[@id='best-sellers_block_right']/div/ul/li[1]/a/img")).click();
		
		if (driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).isDisplayed()){
			System.out.println("I can see Add to Wish LIST under Add Cart");
		}
		driver.findElement(By.xpath("//a[@title='Add to my wishlist']")).click();
		
		if (driver.findElement(By.xpath("//p[text()='Added to your wishlist.']")).isDisplayed()){
			System.out.println("Item Added to Wish LIST Popup appears");
		}
		
		driver.findElement(By.xpath("//a[@title='Close']")).click();
		
		driver.navigate().refresh();
		
		driver.findElement(By.xpath("//a[@title='View my customer account']/span")).click();
		
		driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
		
		
		if (driver.findElement(By.xpath("//*[@id='wishlist_7248']/td[1]")).isDisplayed()){
			System.out.println("Verified Wishlist item in Wishlist page");
		}
		
		
		
		//driver.quit();
	}
}
